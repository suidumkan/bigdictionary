package com.company;

import java.util.*;

public class Main {

    public static void main(String[] args) {

        Map<String, String[]> dictionary = new HashMap<>();
        Map<String, String[]> bigDictinary = new HashMap<>();

        dictionary.put("прекрасный ", new String[]{"отличный ", "блестящий ", "божественный ", "восхитительный "});
        dictionary.put("абитуриент ", new String[]{"выпускник ", "поступающий ", "претендент "});
        dictionary.put("веселый ", new String[]{"радостный ", "беспечальный ", "шутливый ", "счастливый "});
        dictionary.put("друг ", new String[]{"товарищ ", "приятель ", "сторонник "});

        Set<String > keys = dictionary.keySet();
        Iterator<String> iterator = keys.iterator();
        while (iterator.hasNext()){
            String oldKey = iterator.next();
            String[] values = dictionary.get(oldKey);
            bigDictinary.put(oldKey, values);
            for (String newKey: values){
                List<String> listOfValues = new ArrayList<>(values.length);
                listOfValues.addAll(Arrays.asList(values));
                listOfValues.remove(newKey);
                listOfValues.add(oldKey);
                String[] newValues = new String[listOfValues.size()];
                listOfValues.toArray(newValues);
                bigDictinary.put(newKey, newValues);


            }
        }
        for (Map.Entry<String, String[]> item: bigDictinary.entrySet()) {
            System.out.println("Key: " + item.getKey());
            System.out.println("Values: " + Arrays.toString(item.getValue()));

        }
        while (true){
            System.out.println("Введите слово сочетание: (Например: веселый прекрасный друг ) ");
            Scanner scanner = new Scanner(System.in);
            String sentences = scanner.nextLine();
            String[] words = sentences.split(" ");
            for (String word : words){
                String[] sinonyms = bigDictinary.get(word);
                Random random = new Random();
                if (sinonyms != null ){
                    System.out.println(sinonyms[random.nextInt(sinonyms.length)] + " ");
                }
                else {
                    System.out.println("Такого слово сочетания не найдено ");
                    System.out.println("Попробуйте еще раз ");
                }
            }
            System.out.println();
        }
    }


}
/*a)  Копировать все элементы словаря в большой словарь как они есть.
        b)  Затем нужно написать алгоритм автоматического дополнения большого словаря,
        таким образом чтоб каждый из элементов массива синонимов по 1 разу выступил в роли КЛЮЧА
        c)  Текущие ключи маленького словаря также должны будут перейти в массив на роль одного из синонимов.
        d)  Подсказка массив легко конвертируется в ArrayList
        e)  для проверки правильности работы вашего алгоритма
         в конце распечатайте содержимое всего большого словаря*/